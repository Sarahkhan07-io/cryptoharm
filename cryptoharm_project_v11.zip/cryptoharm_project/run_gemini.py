"""Run the CryptoHarm benchmark against Gemini.

Windows cmd:
    set GEMINI_API_KEY=your-key
    python run_gemini.py --repeats 5 --controls --delay 15
    python run_gemini.py --repeats 5 --framing benign --output gemini_benign.json

Re-running the same command resumes from the checkpoint file after a rate limit or crash.
"""
import argparse
import json
import os
import sys

from cryptoharm.run_benchmark import run_benchmark, format_summary_table
from cryptoharm.tasks import TASK_NAMES, CONTROL_TASKS

ap = argparse.ArgumentParser()
ap.add_argument("--model-name", default="gemini-3.8-flash")
ap.add_argument("--repeats", type=int, default=1, help="instances per task/level (10+ recommended)")
ap.add_argument("--framing", default="default", choices=["default", "benign"])
ap.add_argument("--controls", action="store_true", help="also run control tasks (strong RSA)")
ap.add_argument("--delay", type=float, default=0.0, help="seconds to pause after each call, e.g. 15 for free-tier rate limits")
ap.add_argument("--output", default="gemini_results.json")
ap.add_argument("--checkpoint", default="gemini_checkpoint.jsonl")
args = ap.parse_args()

if not os.environ.get("GEMINI_API_KEY"):
    sys.exit("GEMINI_API_KEY is not set. In cmd run:  set GEMINI_API_KEY=your-key")

task_names = list(TASK_NAMES) + (list(CONTROL_TASKS) if args.controls else [])
print("Starting CryptoHarm evaluation on %s (repeats=%d, framing=%s)...\n" % (args.model_name, args.repeats, args.framing))


def progress(done, total, rec):
    print("[%d/%d] task=%-10s level=%d repeat=%d score=%d (%s)%s" % (
        done, total, rec["task"], rec["level"], rec["repeat"], rec["score"], rec["score_label"],
        ("  ERROR: " + rec["error"]) if rec["error"] else ""), flush=True)


out = run_benchmark("gemini", model_name=args.model_name, task_names=task_names, repeats=args.repeats,
                    framing=args.framing, checkpoint_path=args.checkpoint, progress_cb=progress,
                    request_delay=args.delay)
with open(args.output, "w", encoding="utf-8") as fh:
    json.dump(out, fh, indent=2)

print("\nSummary (fraction of runs at each score per hint level):")
print(format_summary_table(out["results"]))
print("\nFull results saved to %s" % args.output)
print("Paper-ready tables:  python -m cryptoharm.analyze %s" % args.output)
