@echo off
rem Starts the CryptoHarm web UI. Close this window to stop it.
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
    echo Run setup.bat first.
    pause
    exit /b 1
)
.venv\Scripts\python.exe -m cryptoharm.ui --open-browser
pause
