"""Connection checker: tells you exactly why a provider is not working.

    python -m cryptoharm.diagnose --provider groq --model openai/gpt-oss-20b
    python -m cryptoharm.diagnose --provider ollama --model <name from `ollama list`>
    python -m cryptoharm.diagnose --provider gemini --model gemini-2.5-flash-lite

The key is read from --key, then the provider's environment variable, then a hidden prompt.
It is never printed.
"""
import argparse
import getpass
import os
import sys

import requests

from cryptoharm.llm_client import make_client, LLMError

PRESETS = {
    "groq": {"base_url": "https://api.groq.com/openai/v1", "env": "GROQ_API_KEY", "type": "openai-compatible"},
    "ollama": {"base_url": "http://localhost:11434/v1", "env": None, "type": "openai-compatible"},
    "openai-compatible": {"base_url": None, "env": "CRYPTOHARM_API_KEY", "type": "openai-compatible"},
    "gemini": {"base_url": None, "env": "GEMINI_API_KEY", "type": "gemini"},
}
NON_CHAT = ("whisper", "orpheus", "guard", "safeguard", "embed", "tts", "transcribe")


def explain(err: str) -> str:
    e = err.lower()
    if "401" in e or "invalid_api_key" in e or "invalid api key" in e:
        return "The API key was rejected. Create a new key and paste it again (no spaces or quotes)."
    if "403" in e:
        return "The key is not allowed to use this model or API. Check the key's permissions or region."
    if "model_not_found" in e or "404" in e:
        return "The model name does not exist for this account. Use a name from the list printed above, exactly."
    if "429" in e or "quota" in e or "rate" in e:
        return "Quota or rate limit reached. Wait a few minutes, use another model, or add a delay between calls."
    if "tool_use_failed" in e:
        return "The model tried to call a tool. Resend, or try another model."
    if "503" in e or "overloaded" in e or "unavailable" in e:
        return "The provider is overloaded right now. Try again in a few minutes."
    if "connection" in e or "refused" in e or "timed out" in e or "timeout" in e:
        return "Could not reach the server. Check the base URL and your internet; for Ollama, make sure it is running."
    return "See the message above."


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="CryptoHarm connection checker")
    ap.add_argument("--provider", required=True, choices=sorted(PRESETS))
    ap.add_argument("--model", default="", help="model name (required except for gemini)")
    ap.add_argument("--base-url", default=None)
    ap.add_argument("--key", default=None)
    ap.add_argument("--max-tokens", type=int, default=None)
    ap.add_argument("--reasoning-effort", default=None, choices=["low", "medium", "high"])
    args = ap.parse_args(argv)

    preset = PRESETS[args.provider]
    base_url = args.base_url or preset["base_url"]
    key = args.key or (os.environ.get(preset["env"]) if preset["env"] else None)
    if not key and preset["env"]:
        key = getpass.getpass("Paste your %s API key (hidden): " % args.provider).strip()
    if key and (key != key.strip() or any(c in key for c in " \"'\r\n")):
        print("[!] The key contains spaces, quotes or line breaks. Removing them.")
        key = "".join(ch for ch in key if ch not in " \"'\r\n")

    ok = True
    print("\n1. Environment")
    print("   python OK, requests %s" % requests.__version__)
    if preset["type"] == "openai-compatible":
        if not base_url:
            print("   [X] No base URL. Pass --base-url https://.../v1")
            return 1
        print("   base URL: %s" % base_url)
        if not args.model:
            print("   [X] No model name. Pass --model <name>")
            return 1

        print("\n2. Model list")
        try:
            r = requests.get(base_url.rstrip("/") + "/models", headers={"Authorization": "Bearer %s" % (key or "")}, timeout=30)
            if r.status_code == 200:
                ids = sorted(m.get("id", "") for m in r.json().get("data", []))
                chat_ids = [i for i in ids if not any(w in i.lower() for w in NON_CHAT)]
                print("   key accepted. %d models, %d look like chat models:" % (len(ids), len(chat_ids)))
                for i in chat_ids:
                    print("     - %s%s" % (i, "   <-- your choice" if i == args.model else ""))
                if args.model not in ids:
                    ok = False
                    print("   [X] '%s' is not in the list. Copy a name exactly from above." % args.model)
            else:
                ok = False
                print("   [X] HTTP %d: %s" % (r.status_code, r.text[:200]))
                print("   -> " + explain("HTTP %d %s" % (r.status_code, r.text)))
        except requests.RequestException as e:
            ok = False
            print("   [X] %s" % e)
            print("   -> " + explain(str(e)))
    else:
        print("\n2. Model list")
        print("   (skipped for gemini)")

    print("\n3. Test message ('Say hello in five words.')")
    try:
        client = make_client(preset["type"], model_name=args.model or None, api_key=key or None, base_url=base_url,
                             max_tokens=args.max_tokens, reasoning_effort=args.reasoning_effort)
        reply = client.chat([{"role": "user", "content": "Say hello in five words."}])
        if reply:
            print("   [OK] reply: %s" % reply.strip()[:200])
        else:
            ok = False
            print("   [X] The provider answered with no text: %s" % getattr(client, "last_block_reason", "unknown reason"))
            print("   -> If the reason mentions length or reasoning, raise --max-tokens (try 16384) and/or use --reasoning-effort low.")
    except LLMError as e:
        ok = False
        print("   [X] %s" % str(e)[:400])
        print("   -> " + explain(str(e)))
    except Exception as e:  # noqa: BLE001
        ok = False
        print("   [X] %s: %s" % (type(e).__name__, e))
        print("   -> " + explain(str(e)))

    print("\nRESULT: %s" % ("everything works. Use these same settings in the UI." if ok else "something needs fixing (see [X] above)."))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
