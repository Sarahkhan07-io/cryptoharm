"""Turn one or more results JSON files into paper-ready tables (Markdown + optional CSV).

    python -m cryptoharm.analyze results.json gemini_results.json --csv summary.csv
"""
import argparse
import csv
import json
import sys
from collections import defaultdict

from cryptoharm.stats import wilson, mcnemar_exact
from cryptoharm.tasks import CONTROL_TASKS


def load(paths):
    rows = []
    for path in paths:
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
        model = data.get("model_name") or data.get("model_type") or path
        framing = (data.get("meta") or {}).get("framing", "default")
        for r in data.get("results", []):
            r = dict(r)
            r["_model"], r["_framing"] = model, framing
            rows.append(r)
    return rows


def _pct(k, n):
    return "%.0f%%" % (100.0 * k / n) if n else "-"


def _ci(k, n):
    lo, hi = wilson(k, n)
    return "%.0f-%.0f%%" % (lo * 100, hi * 100)


def aggregate(rows, keyfn):
    groups = defaultdict(list)
    for r in rows:
        groups[keyfn(r)].append(r)
    return dict(sorted(groups.items()))


def counts(group):
    n = len(group)
    by = [sum(1 for r in group if r["score"] == s) for s in range(4)]
    return n, by, by[3], by[2] + by[3]


def md_table(headers, body):
    out = ["| " + " | ".join(headers) + " |", "|" + "|".join("---" for _ in headers) + "|"]
    out += ["| " + " | ".join(str(c) for c in row) + " |" for row in body]
    return "\n".join(out)


def paired_rows(rows):
    """Exact McNemar tests between consecutive hint levels. The SAME instance (task, repeat) is used at every
    level, so outcomes are paired. Returns table rows."""
    groups = defaultdict(dict)
    for r in rows:
        groups[(r["_model"], r["_framing"])].setdefault((r["task"], r["repeat"]), {})[r["level"]] = r
    out = []
    for (model, framing), inst in sorted(groups.items()):
        levels = sorted({l for d in inst.values() for l in d})
        for a, b in zip(levels, levels[1:]):
            for metric, fn in (("verified recovery", lambda r: r["score"] == 3), ("refusal", lambda r: r["score"] == 0)):
                up = down = n = 0
                for d in inst.values():
                    if a in d and b in d:
                        n += 1
                        x, y = fn(d[a]), fn(d[b])
                        up += (not x) and y
                        down += x and (not y)
                out.append([model, framing, "L%s -> L%s" % (a, b), metric, n, up, down, "%.4f" % mcnemar_exact(up, down)])
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description="Summarise CryptoHarm results")
    ap.add_argument("files", nargs="+")
    ap.add_argument("--csv", default=None, help="write per model/framing/task/level counts to this CSV")
    args = ap.parse_args(argv)
    rows = load(args.files)
    errs = sum(1 for r in rows if r.get("error"))
    rows = [r for r in rows if not r.get("error")]
    if not rows:
        print("no usable results found (%d run(s) had API errors)" % errs)
        return 1
    main_rows = [r for r in rows if r["task"] not in CONTROL_TASKS]
    ctrl_rows = [r for r in rows if r["task"] in CONTROL_TASKS]
    heads = ["model", "framing", "level", "n", "refusal", "generic", "attempt", "verified", "verified 95% CI",
             "engaged (>=2)", "engaged 95% CI"]

    def table(rs, keyfn, prefix_heads):
        body = []
        for key, grp in aggregate(rs, keyfn).items():
            n, by, k3, k23 = counts(grp)
            body.append(list(key) + [n] + [_pct(b, n) for b in by] + [_ci(k3, n), _pct(k23, n), _ci(k23, n)])
        h = prefix_heads + ["n", "refusal", "generic", "attempt", "verified", "verified 95% CI",
                            "engaged (>=2)", "engaged 95% CI"]
        return md_table(h, body)

    print("## Harm-escalation by hint level (all weak tasks pooled)\n")
    print(table(main_rows, lambda r: (r["_model"], r["_framing"], r["level"]), ["model", "framing", "level"]))
    print("\n## By task\n")
    print(table(main_rows, lambda r: (r["_model"], r["_framing"], r["task"], r["level"]),
                ["model", "framing", "task", "level"]))
    pr = paired_rows(main_rows)
    if pr:
        print("\n## Paired comparisons between hint levels (exact McNemar test)\n")
        print("Same instance at every level. 'turned on' = pairs where the outcome went from no to yes, 'turned off' = yes to no.\n")
        print(md_table(["model", "framing", "levels", "outcome", "pairs", "turned on", "turned off", "p (two-sided)"], pr))
        print("\nWith many comparisons, correct for multiple testing (e.g. Holm) before claiming significance.")
    if ctrl_rows:
        print("\n## Controls (strong parameters; verified should be 0%)\n")
        print(table(ctrl_rows, lambda r: (r["_model"], r["_framing"], r["task"], r["level"]),
                    ["model", "framing", "task", "level"]))
    if errs:
        print("\nNote: %d run(s) had API errors and were EXCLUDED from these tables." % errs)
    blocked = sum(1 for r in rows if r.get("provider_block"))
    if blocked:
        print("\nNote: %d of %d run(s) were blocked by the provider before the model answered "
              "(counted as refusal). Report them separately from model-chosen refusals." % (blocked, len(rows)))
    if args.csv:
        with open(args.csv, "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow(["model", "framing", "task", "level", "n", "score0", "score1", "score2", "score3",
                        "verified_ci_low", "verified_ci_high"])
            for (m, f, t, l), grp in aggregate(rows, lambda r: (r["_model"], r["_framing"], r["task"], r["level"])).items():
                n, by, k3, _ = counts(grp)
                lo, hi = wilson(k3, n)
                w.writerow([m, f, t, l, n] + by + [round(lo, 4), round(hi, 4)])
        print("\nwrote %s" % args.csv)
    return 0


if __name__ == "__main__":
    sys.exit(main())
