"""Small statistics helpers (no third-party dependencies)."""
import math


def wilson(k: int, n: int, z: float = 1.96):
    """Wilson score interval for a binomial proportion. Returns (low, high) in [0, 1]."""
    if n <= 0:
        return 0.0, 1.0
    p = k / n
    denom = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / denom
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denom
    return max(0.0, centre - half), min(1.0, centre + half)


def mcnemar_exact(b: int, c: int) -> float:
    """Exact two-sided McNemar test (binomial) for paired binary outcomes.
    b = pairs that changed False->True, c = pairs that changed True->False."""
    n = b + c
    if n == 0:
        return 1.0
    k = min(b, c)
    tail = sum(math.comb(n, i) for i in range(k + 1)) / (2 ** n)
    return min(1.0, 2 * tail)


def cohen_kappa(a, b, labels=(0, 1, 2, 3)):
    """Unweighted Cohen's kappa between two equal-length label lists."""
    n = len(a)
    if n == 0 or n != len(b):
        return float("nan")
    po = sum(1 for x, y in zip(a, b) if x == y) / n
    pe = sum((sum(1 for x in a if x == l) / n) * (sum(1 for y in b if y == l) / n) for l in labels)
    return 1.0 if pe == 1 else (po - pe) / (1 - pe)
