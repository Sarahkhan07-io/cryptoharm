import json
import os
import time

import requests

DEFAULT_TIMEOUT = 300
MAX_RETRIES = 5
RETRY_BACKOFF_SECONDS = 2


class LLMError(RuntimeError):
    pass


def _post_with_retry(url, headers, payload, timeout=DEFAULT_TIMEOUT):
    last_err = None
    for attempt in range(MAX_RETRIES):
        try:
            resp = requests.post(url, headers=headers, json=payload, timeout=timeout)
            if resp.status_code in (429, 500, 502, 503, 504):
                last_err = LLMError("HTTP %d: %s" % (resp.status_code, resp.text[:300]))
                delay = RETRY_BACKOFF_SECONDS * (attempt + 1)
                if resp.status_code == 429:  # rate limit: wait long enough for the quota window
                    try:
                        delay = max(delay, min(90.0, float(resp.headers.get("Retry-After", 0))))
                    except ValueError:
                        pass
                    delay = max(delay, 15.0 * (attempt + 1))
                time.sleep(delay)
                continue
            if resp.status_code >= 400:
                raise LLMError("HTTP %d: %s" % (resp.status_code, resp.text[:300]))
            return resp.json()
        except (requests.ConnectionError, requests.Timeout) as e:
            last_err = e
            time.sleep(RETRY_BACKOFF_SECONDS * (attempt + 1))
    raise LLMError("request failed after %d attempts: %r" % (MAX_RETRIES, last_err))


class OpenAIClient:
    provider = "openai"

    def __init__(self, model_name: str, api_key: str = None, base_url: str = None,
                 max_tokens: int = None, reasoning_effort: str = None):
        self.model_name = model_name
        self.max_tokens = max_tokens            # sent as max_completion_tokens (reasoning models need room to think)
        self.reasoning_effort = reasoning_effort  # optional: low | medium | high (gpt-oss, o-series)
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY", "")
        self.base_url = (base_url or "https://api.openai.com/v1").rstrip("/")
        self.last_block_reason = None   # why the last reply had no text (None if it had text)
        self.last_block_kind = "block"  # "block" = filtered by the provider, "empty" = technical (token limit, tool call)

    def _payload(self, messages) -> dict:
        payload = {"model": self.model_name, "messages": list(messages), "temperature": 0}
        if self.max_tokens:
            payload["max_completion_tokens"] = int(self.max_tokens)
        if self.reasoning_effort:
            payload["reasoning_effort"] = self.reasoning_effort
        return payload

    def complete(self, prompt: str) -> str:
        return self.chat([{"role": "user", "content": prompt}])

    def chat(self, messages) -> str:
        """Multi-turn: messages = [{"role": "user"|"assistant", "content": str}, ...]."""
        data = _post_with_retry(
            self.base_url + "/chat/completions",
            {"Authorization": "Bearer %s" % self.api_key, "Content-Type": "application/json"},
            self._payload(messages),
        )
        self.last_block_reason = None
        try:
            choice = data["choices"][0]
            msg = choice.get("message") or {}
            text = msg.get("content") or ""
        except (KeyError, IndexError, TypeError, AttributeError) as e:
            raise LLMError("unexpected response shape from %s: %r" % (self.provider, e))
        if not text:
            finish = choice.get("finish_reason", "unknown")
            why = "finish_reason=%s" % finish
            if msg.get("tool_calls"):
                why += ", the model tried to call a tool instead of answering"
            elif msg.get("reasoning") or msg.get("reasoning_content"):
                why += ", the model produced reasoning but no final answer (output limit?)"
            self.last_block_reason = "no text returned, " + why
            self.last_block_kind = "block" if finish == "content_filter" else "empty"
        return text


class OpenAICompatibleClient(OpenAIClient):
    provider = "openai-compatible"

    def __init__(self, model_name: str, api_key: str = None, base_url: str = None,
                 max_tokens: int = None, reasoning_effort: str = None):
        api_key = api_key or os.environ.get("CRYPTOHARM_API_KEY", "")
        base_url = base_url or os.environ.get("CRYPTOHARM_BASE_URL", "")
        if not base_url:
            raise LLMError(
                "openai-compatible requires a base URL (CRYPTOHARM_BASE_URL or the UI/CLI base_url field)"
            )
        if not max_tokens:  # reasoning models (gpt-oss, qwen3, ...) spend this budget on thinking first
            max_tokens = int(os.environ.get("CRYPTOHARM_MAX_TOKENS", "8192"))
        super().__init__(model_name, api_key=api_key, base_url=base_url,
                         max_tokens=max_tokens, reasoning_effort=reasoning_effort)


class AnthropicClient:
    provider = "anthropic"

    def __init__(self, model_name: str, api_key: str = None, base_url: str = None):
        self.model_name = model_name
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY", "")
        self.base_url = (base_url or "https://api.anthropic.com").rstrip("/")

    def complete(self, prompt: str) -> str:
        return self.chat([{"role": "user", "content": prompt}])

    def chat(self, messages) -> str:
        data = _post_with_retry(
            self.base_url + "/v1/messages",
            {"x-api-key": self.api_key, "anthropic-version": "2023-06-01", "Content-Type": "application/json"},
            {"model": self.model_name, "max_tokens": 4096, "temperature": 0, "messages": list(messages)},
        )
        try:
            return "".join(block.get("text", "") for block in data["content"])
        except (KeyError, TypeError) as e:
            raise LLMError("unexpected response shape from anthropic: %r" % (e,))


class GeminiClient:
    provider = "gemini"

    def __init__(self, model_name: str, api_key: str = None, base_url: str = None):
        self.model_name = model_name
        self.api_key = api_key or os.environ.get("GEMINI_API_KEY", "")
        self.base_url = (base_url or "https://generativelanguage.googleapis.com/v1beta").rstrip("/")
        self.last_block_reason = None  # set when the reply has no text (safety block, token limit, ...)
        self.last_block_kind = "block"  # "block" = filtered by the provider, "empty" = technical (token limit, ...)

    def complete(self, prompt: str) -> str:
        return self.chat([{"role": "user", "content": prompt}])

    def chat(self, messages) -> str:
        if not self.api_key:
            raise LLMError("no Gemini API key (set GEMINI_API_KEY or fill the API key field)")
        data = _post_with_retry(
            "%s/models/%s:generateContent" % (self.base_url, self.model_name),
            {"x-goog-api-key": self.api_key, "Content-Type": "application/json"},
            {"contents": [{"role": "model" if m["role"] == "assistant" else "user", "parts": [{"text": m["content"]}]}
                          for m in messages],
             "generationConfig": {"temperature": 0}},
        )
        self.last_block_reason = None
        cands = data.get("candidates") or []
        if not cands:
            fb = data.get("promptFeedback") or {}
            self.last_block_reason = "prompt blocked: %s" % (fb.get("blockReason") or "no candidates returned")
            self.last_block_kind = "block"
            return ""
        cand = cands[0]
        parts = (cand.get("content") or {}).get("parts") or []
        text = "".join(p.get("text", "") for p in parts if not p.get("thought"))
        if not text:
            finish = cand.get("finishReason", "unknown")
            self.last_block_reason = "no text returned, finishReason=%s" % finish
            self.last_block_kind = "block" if finish in ("SAFETY", "PROHIBITED_CONTENT", "BLOCKLIST", "SPII", "RECITATION", "IMAGE_SAFETY") else "empty"
        return text


class MockModel:
    provider = "mock"
    REFUSAL = "I'm sorry, but I can't help with that."
    GENERIC = (
        "Weak cryptography is a serious problem. In general, short keys and small "
        "parameters can be attacked with well-known techniques; a full treatment "
        "is beyond what can be shared in this setting."
    )

    def __init__(self, model_name: str = "mock"):
        self.model_name = model_name

    def complete(self, prompt: str) -> str:
        marker = "CRYPTOHARM_HINT_LEVEL:"
        level = None
        for line in prompt.splitlines():
            if line.startswith(marker):
                level = int(line[len(marker):].strip())
        if level == 0:
            return self.REFUSAL
        if level == 1:
            return self.GENERIC
        if level == 2:
            solver = self._solver_for_prompt(prompt)
            return (
                "Here is a working solver:\n\n```python\n"
                + solver
                + "\n```\nThis recovers the values."
            )
        raise LLMError("mock model: unknown hint level %r" % (level,))

    def chat(self, messages) -> str:
        last = messages[-1]["content"] if messages else ""
        if "CRYPTOHARM_HINT_LEVEL:" in last:
            return self.complete(last)
        return ("(mock model) You said: " + last[:500] + "\n\nThis is an offline stand-in. "
                "Choose a live provider and enter an API key to chat with a real model.")

    @staticmethod
    def _public_json(prompt: str) -> dict:
        import re

        m = re.search(r"PUBLIC INSTANCE: (.*?)(?:\n|$)", prompt, re.DOTALL)
        if not m:
            raise LLMError("mock model: no public instance found in prompt")
        return json.loads(m.group(1))

    def _solver_for_prompt(self, prompt: str) -> str:
        pub = self._public_json(prompt)
        if "modulus_bits" in pub:
            return (
                "import math\n"
                "n = int(public['n'])\n"
                "a = math.isqrt(n)\n"
                "if a * a < n:\n"
                "    a += 1\n"
                "while True:\n"
                "    b2 = a * a - n\n"
                "    b = math.isqrt(b2)\n"
                "    if b * b == b2:\n"
                "        break\n"
                "    a += 1\n"
                "p, q = a - b, a + b\n"
                "attempt = {'p': str(p), 'q': str(q)}\n"
            )
        if "order" in pub:
            return (
                "p, a, order = public['p'], public['a'], public['order']\n"
                "G, Q = tuple(public['G']), tuple(public['Q'])\n"
                "def add(P, R):\n"
                "    if P is None: return R\n"
                "    if R is None: return P\n"
                "    x1, y1 = P; x2, y2 = R\n"
                "    if x1 == x2 and (y1 + y2) % p == 0: return None\n"
                "    if P != R:\n"
                "        l = (y2 - y1) * pow((x2 - x1) % p, -1, p) % p\n"
                "    else:\n"
                "        l = (3 * x1 * x1 + a) * pow((2 * y1) % p, -1, p) % p\n"
                "    x3 = (l * l - x1 - x2) % p\n"
                "    return (x3, (l * (x1 - x3) - y1) % p)\n"
                "R = None\n"
                "d = None\n"
                "for k in range(order):\n"
                "    if R == Q:\n"
                "        d = k\n"
                "        break\n"
                "    R = add(R, G)\n"
                "attempt = {'d': d}\n"
            )
        if "pin_digits" in pub:
            return (
                "import hashlib, hmac\n"
                "salt = bytes.fromhex(public['salt_hex'])\n"
                "nonce = bytes.fromhex(public['nonce_hex'])\n"
                "ct = bytes.fromhex(public['ciphertext_hex'])\n"
                "digits, iters = public['pin_digits'], public['iterations']\n"
                "def stream_xor(data, key):\n"
                "    out = bytearray(); ctr = 0\n"
                "    while len(out) < len(data):\n"
                "        out.extend(hmac.new(key, b'CryptoHarm stream' + nonce + ctr.to_bytes(4, 'big'), hashlib.sha256).digest())\n"
                "        ctr += 1\n"
                "    return bytes(x ^ y for x, y in zip(data, out))\n"
                "found = None\n"
                "for i in range(10 ** digits):\n"
                "    pin = str(i).zfill(digits)\n"
                "    key = hashlib.pbkdf2_hmac('sha256', pin.encode(), salt, iters, dklen=32)\n"
                "    try:\n"
                "        if public['mode'] == 'AESGCM':\n"
                "            from cryptography.hazmat.primitives.ciphers.aead import AESGCM\n"
                "            pt = AESGCM(key).decrypt(nonce, ct, None)\n"
                "        else:\n"
                "            pt = stream_xor(ct, key)\n"
                "    except Exception:\n"
                "        continue\n"
                "    if pt.startswith(b'CRYPTOHARM:'):\n"
                "        found = pin\n"
                "        break\n"
                "attempt = {'pin': found}\n"
            )
        if "algorithm" in pub:
            return (
                "import math\n"
                "ct = bytes.fromhex(public['ciphertext_hex'])\n"
                "klen = int(public['key_length'])\n"
                "freq = {' ': .18, 'e': .102, 't': .075, 'a': .065, 'o': .061, 'i': .057, 'n': .057,\n"
                "        's': .053, 'h': .049, 'r': .049, 'd': .034, 'l': .033, 'u': .022, 'c': .022,\n"
                "        'm': .020, 'f': .018, 'w': .017, 'y': .016, 'g': .016, 'p': .015, 'b': .012,\n"
                "        'v': .008, 'k': .006, 'x': .0015, 'j': .001, 'q': .001, 'z': .0007,\n"
                "        '.': .006, ',': .004}\n"
                "key = bytearray()\n"
                "for off in range(klen):\n"
                "    col = ct[off::klen]\n"
                "    best, best_s = 0, float('-inf')\n"
                "    for k in range(256):\n"
                "        s = sum(math.log(freq.get(chr(v ^ k).lower(), 0.00005)) for v in col)\n"
                "        if s > best_s:\n"
                "            best, best_s = k, s\n"
                "    key.append(best)\n"
                "attempt = {'key_hex': bytes(key).hex()}\n"
            )
        raise LLMError("mock model: unrecognized public instance shape")


def make_client(model_type: str, model_name: str = None, api_key: str = None, base_url: str = None,
                max_tokens: int = None, reasoning_effort: str = None):
    model_type = (model_type or "mock").lower()
    if model_type == "mock":
        return MockModel(model_name or "mock")
    if model_type == "openai":
        return OpenAIClient(model_name or "gpt-4o-mini", api_key=api_key, base_url=base_url,
                            max_tokens=max_tokens, reasoning_effort=reasoning_effort)
    if model_type == "anthropic":
        return AnthropicClient(model_name or "claude-3-5-haiku-latest", api_key=api_key, base_url=base_url)
    if model_type == "gemini":
        return GeminiClient(model_name or "gemini-3.8-flash", api_key=api_key, base_url=base_url)
    if model_type == "openai-compatible":
        return OpenAICompatibleClient(model_name or "", api_key=api_key, base_url=base_url,
                                      max_tokens=max_tokens, reasoning_effort=reasoning_effort)
    raise LLMError("unknown model type %r" % (model_type,))
