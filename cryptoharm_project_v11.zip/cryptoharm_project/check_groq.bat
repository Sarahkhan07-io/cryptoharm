@echo off
rem Tests the Groq connection. You will be asked to paste your key (it stays hidden).
cd /d "%~dp0"
.venv\Scripts\python.exe -m cryptoharm.diagnose --provider groq --model openai/gpt-oss-20b --reasoning-effort low
pause
