EASIEST WAY (Windows):
  1. Double-click setup.bat (first time only)
  2. Double-click check_groq.bat to test your Groq key and model
  3. Double-click run_ui.bat to open the app

Connection checker for any provider:
  python -m cryptoharm.diagnose --provider groq --model openai/gpt-oss-20b
  python -m cryptoharm.diagnose --provider ollama --model <name>
  python -m cryptoharm.diagnose --provider gemini --model <name>

CryptoHarm v0.2.0 - Windows quick start (Command Prompt / VS Code terminal)

SETUP (first time; every new terminal needs  .venv\Scripts\activate  before running anything)
  cd /d D:\cryptoharm_project
  py -m venv .venv
  .venv\Scripts\activate
  pip install -r requirements.txt

TEST THAT EVERYTHING WORKS (no API key)
  python -m unittest discover -s tests -t .
  python -m cryptoharm.run_benchmark --model mock --include-controls

RUN ON GEMINI
  set GEMINI_API_KEY=your-key
  python run_gemini.py --repeats 10 --controls --delay 15      (--delay = seconds to pause after each call; avoids rate limits)
  python run_gemini.py --repeats 10 --framing benign --output gemini_benign.json --checkpoint gemini_benign.jsonl
  (If it stops from a rate limit, run the same command again: it resumes from the checkpoint.)

OTHER MODELS (command line)
  set OPENAI_API_KEY=...   then   python -m cryptoharm.run_benchmark --model openai --model-name gpt-4o-mini --repeats 10 --checkpoint oa.jsonl
  set ANTHROPIC_API_KEY=... then  python -m cryptoharm.run_benchmark --model anthropic --model-name <model> --repeats 10 --checkpoint an.jsonl

PAPER TABLES (Wilson 95% confidence intervals, per level and per task)
  python -m cryptoharm.analyze gemini_results.json gemini_benign.json --csv summary.csv

WEB UI
  python -m cryptoharm.ui --open-browser
  Two tabs: Benchmark (scored runs) and Chat (talk to the selected model directly; nothing is scored or executed).
  The chat history lives in the browser tab only; refreshing the page clears it.

WHAT'S NEW IN 0.2.0
  - --repeats N: N instances per task/level; the SAME instance is used at every hint level (paired design)
  - Wilson 95% CIs in all summary tables
  - Control task rsa_strong (--include-controls / --controls): strong RSA; the hinted attack must fail
  - --framing benign: classroom-CTF framing, to separate refusal from capability
  - --checkpoint file.jsonl: resumable runs (API errors are retried on resume)
  - Metadata (harness version, date, executor, timeout, prompt hash) saved in the results
  - Patient retry on HTTP 429 (honours Retry-After)
  - Scoring handles curly apostrophes and more refusal phrases
  - Optional Docker executor for stronger isolation (see Dockerfile; NOT tested by the author of this update)
  - Unit tests in tests/

KNOWN LIMITS (state these in the paper)
  - Scores 0-2 use a keyword heuristic; only score 3 is execution-verified. Hand-label a sample and report agreement.
  - Default executor is a best-effort subprocess, not a hardened sandbox. Use the Docker executor or a VM.
  - Instances are toy-sized, so results measure willingness/competence on trivial problems.
