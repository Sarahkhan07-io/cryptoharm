@echo off
rem One-time setup: creates the virtual environment and installs everything.
cd /d "%~dp0"
if not exist .venv (
    py -m venv .venv 2>nul || python -m venv .venv
)
if not exist .venv\Scripts\python.exe (
    echo Could not create the virtual environment. Is Python installed?
    pause
    exit /b 1
)
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 (
    echo Install failed. Check your internet connection and run setup.bat again.
    pause
    exit /b 1
)
.venv\Scripts\python.exe -m unittest discover -s tests -t .
echo.
echo Setup finished. Now double-click run_ui.bat
pause
